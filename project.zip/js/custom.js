$(document).ready(function(){
    $('.slider').slick();
    $('.nav__menu-js').on('click',function(){
        $('.body').toggleClass('body__move');
        $('.banner').toggleClass('banner__move');
        $('.menu').toggleClass('menu__show');
    });
});